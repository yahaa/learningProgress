package com.zihua.test;
public class B{
	public void fb(){
		System.out.println("I am B");
	}
}