package com.zihua.test;
public class Hello{
	public static void main(String[]args){
		System.out.println("很高兴学习Java");
	}

}