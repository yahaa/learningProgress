package com.zihua.test;
public class C{
	public void fc(){
		System.out.println("I am C");
	}
}