package com.zihua.test;
public class A{
	public void fa(){
		System.out.println("I am A");
		System.out.println("我是 A 我被修改了");
	}
}